var box = document.getElementById("box");
var layer = document.getElementById("layer");
var mask = document.getElementById("mask");
var inputBrowser = document.getElementById("inputBrowser");
var iconArrow = document.getElementById("icon-arrow");
EventUtil.addHandler(box,"click",function(event){
    event = EventUtil.getEvent(event);
    var target = EventUtil.getTarget(event);
    // console.log(target.localName);
    // 点击添加
    if(target.localName=='a'){
        var W = document.body.clientWidth;
        var H = document.body.clientHeight;
        var targetH = target.offsetHeight;
        var targetW = target.offsetWidth;
        var offsetTop = target.offsetTop;
        var offsetLeft = target.offsetLeft;
        console.log('H:' + H)
        console.log('targetH:' + targetH)
        console.log('offsetTop:' + offsetTop)
        if(W>=1024){
            layer.className='layer layer-position';
            layer.style.left = offsetLeft - targetW + 'px';
            if(offsetTop + targetH + 176 > H){
                layer.style.top = offsetTop - 176 + 'px';
                iconArrow.className = 'icon-arrow iconfont icon-jiantou down'
                
            } else{
                layer.style.top = offsetTop + targetH + 15 + 'px';
                 iconArrow.className = 'icon-arrow iconfont icon-jiantou up'
            }
        };
        if(W<1024){
            layer.className='layer ipad-position';
            mask.className='mask';
        };
        if(W<768){
            layer.className='layer wap-position';
            mask.className='mask';
        };
        // console.log(offsetTop + '\n' + offsetLeft);
        // 点击弹层
        EventUtil.addHandler(layer,"click",function(event){
            event = EventUtil.getEvent(event);
            var _this = EventUtil.getTarget(event);
            if(_this.id=='close' || _this.id=='cancel'){
                layer.className='layer hide';
                mask.className='mask hide';
                inputBrowser.value = '';
            };
            if(_this.id=='addResources'){
                layer.className='layer hide';
                mask.className='mask hide';
                var arrBrowser = [];
                var inputValue = inputBrowser.value;
                var arrBrowser = inputValue.split(',');
                inputBrowser.value = '';
                console.log(arrBrowser);
                var createLabel = "";
                arrBrowser.forEach(function(element){
                    createLabel += '<span>'+ element + '<i class="iconfont icon-tubiaozhizuo-"></i></span>';
                });
                var labelList = target.parentNode.nextElementSibling;
                labelList.insertAdjacentHTML('beforeEnd',createLabel);
                // console.log(target.parentNode.nextElementSibling.className);
            }
        });
    }
    // 点击删除
    if(target.className== 'iconfont icon-tubiaozhizuo-'){
        var currentBrowser = target.parentNode;
        var currentBrowserVal = currentBrowser.innerHeight;
        currentBrowser.parentNode.removeChild(currentBrowser);
        console.log(currentBrowser);
    }
});
// window.onresize = function(){
//
// };
var totalData = [
    {
        "ProductImgClass": "product-img product-img-win iconfont icon-win",
        "Url": "https://www.baidu.com/",
        "U_icon": "iconfont icon-diannao",
        "Label": "idle",
        "L_class": "label green",
        "IP": "192.168.2.102",
        "IP_icon": "iconfont icon-jinggao",
        "Path": "\CaiTong\Desktop\CRUISE",
        "P_icon": "iconfont icon-icon-test",
        "Add_btn": "add-browser iconfont icon-tianjia-",
        Browser_list:['Firefox','Safari','Ubuntu','Chrome'],
        "Deny_class":"deny hide"
    },
    {
        "ProductImgClass": "product-img product-img-win iconfont icon-win",
        "Url": "https://www.baidu.com/",
        "U_icon": "iconfont icon-diannao",
        "Label": "building",
        "L_class": "label orange",
        "IP": "192.168.2.102",
        "IP_icon": "iconfont icon-jinggao",
        "Path": "\CaiTong\Desktop\CRUISE",
        "P_icon": "iconfont icon-icon-test",
        "Add_btn": "add-browser iconfont icon-tianjia-",
        Browser_list:['Firefox','Safari','Ubuntu','Chrome'],
        "Deny_class":"deny"
    },
    {
        "ProductImgClass": "product-img product-img-win iconfont icon-win",
        "Url": "https://www.baidu.com/",
        "U_icon": "iconfont icon-diannao",
        "Label": "building",
        "L_class": "label orange",
        "IP": "192.168.2.102",
        "IP_icon": "iconfont icon-jinggao",
        "Path": "\CaiTong\Desktop\CRUISE",
        "P_icon": "iconfont icon-icon-test",
        "Add_btn": "add-browser iconfont icon-tianjia-",
        Browser_list:['Firefox','Chrome'],
        "Deny_class":"deny"
    },
    {
        "ProductImgClass": "product-img product-img-win iconfont icon-win",
        "Url": "https://www.baidu.com/",
        "U_icon": "iconfont icon-diannao",
        "Label": "building",
        "L_class": "label orange",
        "IP": "192.168.2.102",
        "IP_icon": "iconfont icon-jinggao",
        "Path": "\CaiTong\Desktop\CRUISE",
        "P_icon": "iconfont icon-icon-test",
        "Add_btn": "add-browser iconfont icon-tianjia-",
        Browser_list:['Firefox','Safari','Chrome'],
        "Deny_class":"deny"
    },
    // {
    //     "ProductImgClass": "product-img product-img-win iconfont icon-win",
    //     "Url": "https://www.baidu.com/",
    //     "U_icon": "iconfont icon-diannao",
    //     "Label": "idle",
    //     "L_class": "label green",
    //     "IP": "192.168.2.102",
    //     "IP_icon": "iconfont icon-jinggao",
    //     "Path": "\CaiTong\Desktop\CRUISE",
    //     "P_icon": "iconfont icon-icon-test",
    //     "Add_btn": "add-browser iconfont icon-tianjia-",
    //     Browser_list:[],
    //     "Deny_class":"deny hide"
    // },
    {
        "ProductImgClass": "product-img product-img-win iconfont icon-win",
        "Url": "https://www.baidu.com/",
        "U_icon": "iconfont icon-diannao",
        "Label": "idle",
        "L_class": "label green",
        "IP": "192.168.2.102",
        "IP_icon": "iconfont icon-jinggao",
        "Path": "\CaiTong\Desktop\CRUISE",
        "P_icon": "iconfont icon-icon-test",
        "Add_btn": "add-browser iconfont icon-tianjia-",
        Browser_list:['Firefox','Safari','Ubuntu','Chrome'],
        "Deny_class":"deny hide"
    }
];
var _html = "";
totalData.forEach(function(element,index) {
    // console.log(element.Browser_list);
    _html += '<div class="margin-t15 flex flex-start module border-'+ element.Label +'" id="module' + index + '">';
    _html += '<span class="' + element.ProductImgClass + '"></span>';
    _html += '<div class="module-cont">';
    _html += '<div class="module-cont-top">';
    _html += '<span class="url"><i class="' + element.U_icon + '"></i>' + element.Url + '</span>';
    _html += '<span class="'+ element.L_class + '">' + element.Label + '</span>';
    _html += '<span class="IP"><i class="' + element.IP_icon + '"></i>' + element.IP + '</span>';
    _html += '<span class="path"><i class="' + element.P_icon + '"></i>' + element.Path + '</span>';
    _html += '</div>';
    _html += '<div class="module-cont-bottom flex space-between"><div class="flex flex-start">';
    _html += '<div class="js-addBtn"><a class="add-browser iconfont icon-tianjia-" href="javascript:;"></a></div>';
    _html += '<div class="label-list">';
    for(let i = 0;i<element.Browser_list.length;i++){
        _html += '<span>'+ element.Browser_list[i] + '<i class="iconfont icon-tubiaozhizuo-"></i></span>';
    }
    _html += '</div></div>';
    _html += '<span class="'+ element.Deny_class +  '"><i class="iconfont icon-ai55"></i>Deny</span>';
    _html += '</div></div></div>';
});
box.insertAdjacentHTML('beforeEnd',_html);





// para.appendChild(node);







